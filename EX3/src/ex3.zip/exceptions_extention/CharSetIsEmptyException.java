package exceptions_extention;

/**
 *  Exception Class - special exception for cases in which program required to create the
 *  ascii art but current charSet is empty.
 */
public class CharSetIsEmptyException extends Exception{}
