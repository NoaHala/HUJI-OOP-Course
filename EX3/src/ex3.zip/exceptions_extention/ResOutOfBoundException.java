package exceptions_extention;

/**
 *  Exception Class - special exception for cases in which the required resolution is out of bound.
 */
public class ResOutOfBoundException extends Exception{}
