package exceptions_extention;


/**
 *  Exception Class - special exception for cases in which the program couldn't open or use the given image.
 */
public class OpenImageException extends Exception {}
